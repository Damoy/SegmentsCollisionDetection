package com.dzoum.sdc.core.collision;

public final class CollisionDetector {
	
	private CollisionDetector() {}
	
}
